Kids TV
=======

Using smart playlists and Emby tagging, present a bunch of playlists that can be used to group together TV and Movies (such as programmes for kids).
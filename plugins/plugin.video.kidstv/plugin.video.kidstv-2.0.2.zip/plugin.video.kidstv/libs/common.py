#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2019 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Shared code fragments used by the add-on.

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
import urllib

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, ifJSONTrace, newPrint, getID


LOCAL = r"/local/"


def getPlaylists(with_ext, with_full_path):
    # Get the current set of playlists from the playlist directory
    addon = xbmcaddon.Addon(getID())
    playlists_path = getPlaylistsPath("")
    prefix = addon.getSetting("playlist_prefix");
    playlists = []
    debugTrace("Listing playlists from " + playlists_path)
    try:
        dirs, files = xbmcvfs.listdir(playlists_path)
        if len(files) > 0:
            for file in files:          
                if file.startswith(prefix) and file.endswith(".xsp"):
                    if with_ext:
                        playlists.append(file)
                    elif with_full_path:
                        playlists.append(getPlaylistsPath(file))
                    else:
                        playlists.append(file[:-4])
    except Exception as e:  
        errorTrace("common.py", "Couldn't list " + playlists_path)
        errorTrace("common.py", str(e))    
    return playlists


def setHiddenPlaylists(playlists, hidden_playlists_indexes):
    # Store the list of playlists which have been marked hidden
    debugTrace("Setting hidden attributes for each playlist")
    # Translate playlist indexes into a list of playlists to be hidden
    hidden_playlists = []
    for i in hidden_playlists_indexes:
         hidden_playlists.append(playlists[i])
    # Parse through the JSON data, updating each playlist hidden value pair
    json_data = readJSONData()
    json_playlists = json_data.get("playlists")
    for p in json_playlists:
        if p.get("playlist") in hidden_playlists:
            p["hidden"] = True
        else:
            p["hidden"] = False
    # Save updates
    writeJSONData(json_data)
            

def getHiddenPlaylists(playlists):
    # Given the current playlists, return the index of those currently marked as hidden
    indexes = []
    debugTrace("Refreshing JSON in case there are new playlists, and getting hidden settings")
    json_data = refreshJSONData(playlists)
    for p in playlists:
        found, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined = getPlaylistData(json_data, p, True)
        if hidden:
            indexes.append(playlists.index(p))
    return indexes
    
    
def setAutoPlayPlaylists(playlists, autoplay_playlists_indexes):
    # Store the list of playlists which have been marked autoplay
    debugTrace("Setting autoplay attributes for each playlist")
    # Translate playlist indexes into a list of playlists to be autoplayed
    autoplay_playlists = []
    for i in autoplay_playlists_indexes:
         autoplay_playlists.append(playlists[i])
    # Parse through the JSON data, updating each playlist autoplay value pair
    json_data = readJSONData()
    json_playlists = json_data.get("playlists")
    for p in json_playlists:
        if p.get("playlist") in autoplay_playlists:
            p["autoplay"] = True
        else:
            p["autoplay"] = False
    # Save updates
    writeJSONData(json_data)
            

def getAutoPlayPlaylists(playlists):
    # Given the current playlists, return the index of those currently marked as autoplay
    indexes = []
    debugTrace("Refreshing JSON in case there are new playlists, and getting autoplay settings")
    json_data = refreshJSONData(playlists)
    for p in playlists:
        found, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined = getPlaylistData(json_data, p, True)
        if autoplay:
            indexes.append(playlists.index(p))
    return indexes


def getMovieLibrary():    
    # Get movie data from Kodi
    debugTrace("Getting JSON movie data")
    response = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "params": {"sort": {"order": "ascending", "method": "title"}, "properties": ["title", "art", "file", "tagline"]}, "method": "VideoLibrary.GetMovies", "id": "libMovies"}')
    json_data = json.loads(response)
    if ifJSONTrace(): debugTrace(json.dumps(json_data, indent=4, sort_keys=True))
    return json_data


def getTVLibrary():    
    # Get TV data from Kodi
    debugTrace("Getting JSON TV data")
    response = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": { "properties": ["title", "art", "plot", "file"], "sort": { "order": "ascending", "method": "label" } }, "id": "libTvShows"}')
    json_data = json.loads(response)
    if ifJSONTrace(): debugTrace(json.dumps(json_data, indent=4, sort_keys=True))    
    return json_data
    
            
def refreshJSONData(playlists):
    # Refresh the data from the Kodi JSON data.  Preserve any user settings
    # Only the TV data is queried because a group of movies would need user defined graphics
    addon = xbmcaddon.Addon(getID())
    prefix = addon.getSetting("playlist_prefix");
    tv_json_data = getTVLibrary()
    existing_json_data = readJSONData()
    json_str = '{"playlists" : [\n'
    for p in playlists:
        # Work out what kinda playlist this is
        tvshow, multiple = getTVShowFromPlaylist(getPlaylistsPath(p + ".xsp"))
        json_str = json_str + '{"playlist": "' + p + '", '
        # Get the existing data from the the addon data
        e_found = False
        e_user_defined = False
        if not existing_json_data == None:
            e_found, e_title, e_plot, e_thumb, e_fanart, e_poster, e_hidden, e_autoplay, e_user_defined = getPlaylistData(existing_json_data, p, True)
        if not multiple and not tvshow == None:
            # For TV show playlists, get most of the info from Kodi JSON, unless it's been over written by user data
            title, plot, thumb, fanart, poster = getTVShowData(tv_json_data, tvshow)
            json_str = json_str + '"title": "' + title + '",'
            json_str = json_str + '"plot": "' + plot + '",'
            if e_user_defined: 
                json_str = json_str + '"thumb": "' + urllib.unquote(e_thumb.encode("utf-8")) + '",'
                json_str = json_str + '"fanart": "' + urllib.unquote(e_fanart.encode("utf-8")) + '",'
                json_str = json_str + '"poster": "' + urllib.unquote(e_poster.encode("utf-8")) + '",'     
            else:
                json_str = json_str + '"thumb": "' + thumb + '",'
                json_str = json_str + '"fanart": "' + fanart + '",'
                json_str = json_str + '"poster": "' + poster + '",'
        else:
            # Multiple TV shows, or a movie playlist, can only use any existing data
            json_str = json_str + '"title": "' + p.replace(prefix, "") + '",'
            if not existing_json_data == None:
                json_str = json_str + '"thumb": "' + urllib.unquote(e_thumb.encode("utf-8")) + '",'
                json_str = json_str + '"fanart": "' + urllib.unquote(e_fanart.encode("utf-8")) + '",'
                json_str = json_str + '"poster": "' + urllib.unquote(e_poster.encode("utf-8")) + '",'
        # If this playlist is not new, just retain the settings
        if e_found:
            json_str = json_str + '"hidden": ' + str(e_hidden).lower() + ','
            json_str = json_str + '"autoplay": ' + str(e_autoplay).lower() + ','
            json_str = json_str + '"user defined": ' + str(e_user_defined).lower() + '}'
        else:
            json_str = json_str + '"hidden": false,'
            json_str = json_str + '"autoplay": false,'
            json_str = json_str + '"user defined": false}'
        if not p == playlists[-1]: json_str = json_str + ","
        json_str = json_str + '\n'
    json_str = json_str + ']\n}\n'
    newPrint(json_str)
    json_data = json.loads(json_str)
    if ifJSONTrace(): debugTrace(json.dumps(json_data, indent=4, sort_keys=True))
    writeJSONData(json_data)
    return json_data
   

def readJSONData():
    # Read addon data in, in JSON format
    if xbmcvfs.exists(getDataName()):
        try:
            f = open(getDataName(), 'r')
            json_data = json.load(f)
            f.close()
            return json_data
        except Exception as e:
            errorTrace("common.py", "Could not read " + getDataName())
            errorTrace("common.py", str(e))
    return None
           

def writeJSONData(json_data):
    # Write addon data out in JSON format
    try:
        f = open(getDataName(), 'w')
        json.dump(json_data, f, indent=4, sort_keys=True)
        f.close()
        return True
    except Exception as e:
        errorTrace("common.py", "Could not read " + getDataName())
        errorTrace("common.py", str(e))
        return False  


def getPlaylistData(json_data, playlist, raw):
    # Get the data for a playlist from the addon data JSON
    playlists = json_data.get("playlists")
    for p in playlists:
        if p.get("playlist") == playlist:
            title = p.get("title")
            if title == None: title = ""
            plot = p.get("plot")
            if plot == None: plot = ""
            thumb = p.get("thumb")
            if thumb == None: thumb = ""
            if not raw and thumb.startswith(LOCAL): 
                thumb = thumb.replace(LOCAL, "")
                thumb = getUserDataPath("cache/" + thumb)
            fanart = p.get("fanart")
            if fanart == None: fanart = ""
            if not raw and fanart.startswith(LOCAL): 
                fanart = fanart.replace(LOCAL, "")
                fanart = getUserDataPath("cache/" + fanart)
            poster = p.get("poster")
            if poster == None: poster = ""
            if not raw and poster.startswith(LOCAL): 
                poster = poster.replace(LOCAL, "")
                poster = getUserDataPath("cache/" + poster)
            hidden = p.get("hidden")
            if hidden == None: hidden = ""
            autoplay = p.get("autoplay")
            if autoplay == None: autoplay = ""
            user_defined = p.get("user defined")
            if user_defined == None: user_defined = ""
            return True, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined
    return False, "", "", "", "", "", "", "", ""

    
def getTVShowData(json_data, tvshow):
    # Get the TV show data from the Kodi TV JSON data for a particular show
    results = json_data.get("result")
    tvshows = results.get("tvshows")
    for t in tvshows:
        title = urllib.unquote(t.get("title")).encode("utf-8")
        plot = ""
        thumb = ""
        fanart = ""
        poster = ""
        if tvshow == title:
            plot = getURLData(t, "plot", "")
            thumb = getURLData(t, "art", "thumb")
            fanart = getURLData(t, "art", "fanart")
            poster = getURLData(t, "art", "poster")
            return title, plot, thumb, fanart, poster
    return tvshow, "", "", "", ""


def getURLData(t, type, format):
    d = ""
    try:
        if not format == "":
            d = urllib.unquote((t.get(type)).get(format)).encode("utf-8")
        else:
            d = urllib.unquote(t.get(type)).encode("utf-8")
        d = d.replace("image://", "")
        return d
    except Exception as e:
        errorTrace("common.py", "Could not get " + type + ", " + format)
        errorTrace("common.py", str(e))
        return ""
        
        
def getTVShowFromPlaylist(playlist):
    # Could read the playlist using an xml parser, but reading in and parsing the
    # playlist for the TV show is quicker and cheaper
    debugTrace("Parsing playlist " + playlist)
    tvshow = None
    multiple = False
    try:
        f = open(playlist, 'r')
        xml = f.readlines()
        f.close()
    except Exception as e:
        errorTrace("common.py", "Could not read playlist " + playlist)
        errorTrace("common.py", str(e))
        return None
    found = False
    for l in xml:
        l = l.strip(' \t\n\r')
        if not found:
            if l.startswith('<rule field="tvshow"') or l.startswith('<rule field="title"'):
                found = True
        else:
            if l.startswith('<value>'):
                l = l.replace('<value>', "")
                l = l.replace('</value>', "")                
                l = urllib.unquote(l.encode("utf-8"))
                l = unescape(l)
                if tvshow == None: tvshow = l
                else: multiple = True
    return tvshow, multiple
        

def unescape(input):
    # Unescape some common HTML tags that appear in Kodi XML playlists
    output = input
    output = output.replace("&lt;", "<")
    output = output.replace("&gt;", ">")
    output = output.replace("&apos;", "'")
    output = output.replace("&quot;", '"')
    # This must be last!
    output = output.replace("&amp;", "&")
    return output
    

def ensureUserDataDirectories():
    # Ensure data directories exists in userdata
    user_directory = getUserDataPath("data/")
    try:
        if not xbmcvfs.exists(user_directory):
            xbmcvfs.mkdir(user_directory)
        user_directory = getUserDataPath("cache/")
        if not xbmcvfs.exists(user_directory):
            xbmcvfs.mkdir(user_directory)
        return True
    except Exception as e:
        errorTrace("common.py", "Could not create " + user_directory)
        errorTrace("common.py", str(e))
        return False

    
def getDataName():        
    ensureUserDataDirectories()
    return getUserDataPath("data/playlists.txt")    
    
    
def getPlaylistsPath(playlist):
    path = "special://userdata/playlists/video/"
    if not playlist == "": path = path + playlist
    return xbmc.translatePath(path)
    

def getUserDataPath(file):
    path = "special://userdata/addon_data/" + getID() + "/"
    if not file == "": path = path + file
    return xbmc.translatePath(path)    
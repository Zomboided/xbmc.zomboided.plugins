#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2016 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Copy the playlists used by Kids TV between local and sync locations

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs
import os

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, newPrint, getID
from libs.common import getUserDataPath

action = sys.argv[1]

debugTrace("-- Entered movePlaylists.py with parameter " + action + " --")

addon = xbmcaddon.Addon("plugin.video.kidstv")
addon_name = addon.getAddonInfo("name")
addon_id = addon.getAddonInfo('id')

playlist_source = xbmc.translatePath("special://userdata/playlists/video/")
data_source = getUserDataPath("data/")
cache_source = getUserDataPath("cache/")
destination = addon.getSetting("playlist_location")
prefix = addon.getSetting("playlist_prefix");


# Ensure an empty directory is available to copy files to
def prepareDirectory(directory_name):
    try:
        if xbmcvfs.exists(directory_name):
            dirs, files = xbmcvfs.listdir(directory_name)
            if len(files) > 0:
                for file in files:          
                    xbmcvfs.delete(directory_name + file)
        else:
            xbmcvfs.mkdir(directory_name)
    except Exception as e:
        errorTrace("movePlaylists.py", "Could not prepare " + directory_name)
        errorTrace("movePlaylists.py", str(e))


if action == "backup":
    # Copy local to remote
    if not destination == "":
        if xbmcgui.Dialog().yesno(addon_name, "Backup Kids TV playlists and data?"):        
            # Remove any existing files from destination location
            prepareDirectory(destination)
            prepareDirectory(destination + "data/")
            prepareDirectory(destination + "cache/")
            # Copy from local playlist location to the destination location
            dirs, files = xbmcvfs.listdir(playlist_source)
            playlist_count = 0
            if len(files) > 0:
                for file in files:          
                    if file.startswith(prefix) and file.endswith(".xsp"):                
                        try:
                            if xbmcvfs.copy(playlist_source + file, destination + file):
                                playlist_count = playlist_count + 1
                        except Exception as e:
                            errorTrace("movePlaylists.py", "Could not copy " + playlist_source + file + " to " + destination)
                            errorTrace("movePlaylists.py", str(e))
            # Copy from the addon data directory
            dirs, files = xbmcvfs.listdir(data_source)
            data_count = 0
            if len(files) > 0:
                for file in files:          
                    try:
                        if xbmcvfs.copy(data_source + file, destination + "data/" + file):
                            data_count = data_count + 1
                    except Exception as e:
                        errorTrace("movePlaylists.py", "Could not copy " + data_source + file + " to " + destination + "data/")
                        errorTrace("movePlaylists.py", str(e))
            # Copy from the addon cache directory
            dirs, files = xbmcvfs.listdir(cache_source)
            cache_count = 0
            if len(files) > 0:
                for file in files:          
                    try:
                        if xbmcvfs.copy(cache_source + file, destination + "cache/" + file):
                            cache_count = cache_count + 1
                    except Exception as e:
                        errorTrace("movePlaylists.py", "Could not copy " + cache_source + file + " to " + destination + "cache/")
                        errorTrace("movePlaylists.py", str(e))
            message = ""
            if playlist_count == 0: message = message + "No playlists were backed up.\n"
            else: message = message + str(playlist_count) + " playlists were backed up.\n"
            if data_count == 0: msesage = message + "No data was backed up.\n"
            else: message = message + "Data backed up.\n"
            if cache_count == 0: message = message + "No cache was backed up."
            else: message = message + "Cache backed up."
            xbmcgui.Dialog().ok(addon_name, message)
    else:
        xbmcgui.Dialog().ok(addon_name, "Select a backup directory")


elif action == "refresh":
    # Copy remote to local
    if xbmcgui.Dialog().yesno(addon_name, "Restore Kids TV playlists and data from backup (overwrite all current)?"):
        # See if there are any playlists to copy
        dirs, files = xbmcvfs.listdir(destination)
        playlist_count = 0
        if len(files) > 0:            
            for file in files:          
                if file.startswith(prefix) and file.endswith(".xsp"):                
                    playlist_count = playlist_count + 1
        # Remove local playlists and update with destination playlists
        if playlist_count > 0:    
            # Remove any existing local addon playlists, don't delete all playlists though
            dirs, files = xbmcvfs.listdir(playlist_source)
            if len(files) > 0:
                for file in files:
                    try:
                        if file.startswith(prefix) and file.endswith(".xsp"):                
                            xbmcvfs.delete(playlist_source + file)
                    except Exception as e:
                        errorTrace("movePlaylists.py", "Could not delete " + playlist_source + file)
                        errorTrace("movePlaylists.py", str(e))
            # Copy from destination location to the local playlist location
            dirs, files = xbmcvfs.listdir(destination)
            playlist_count = 0
            if len(files) > 0:            
                for file in files:          
                    if file.startswith(prefix) and file.endswith(".xsp"):
                        try:
                            if xbmcvfs.copy(destination + file, playlist_source + file):
                                playlist_count = playlist_count + 1        
                        except Exception as e:
                            errorTrace("movePlaylists.py", "Could not copy " + destination + file + " to " + playlist_source + "cache/")
                            errorTrace("movePlaylists.py", str(e))
            # Clear out the cache
            prepareDirectory(cache_source)
            # Update the cache from backup
            dirs, files = xbmcvfs.listdir(destination + "cache/")
            cache_count = 0
            if len(files) > 0:            
                for file in files:          
                    try:
                        if xbmcvfs.copy(destination + "cache/" + file, cache_source + file):
                            cache_count = cache_count + 1        
                    except Exception as e:
                        errorTrace("movePlaylists.py", "Could not copy " + destination + "cache/" + file + " to " + cache_source)
                        errorTrace("movePlaylists.py", str(e))
            # Clear out the data
            prepareDirectory(data_source)
            # Update the data from backup
            dirs, files = xbmcvfs.listdir(destination + "data/")
            data_count = 0
            if len(files) > 0:            
                for file in files:          
                    try:
                        if xbmcvfs.copy(destination + "data/" + file, data_source + file):
                            data_count = data_count + 1        
                    except Exception as e:
                        errorTrace("movePlaylists.py", "Could not copy " + destination + "data/" + file + " to " + data_source)
                        errorTrace("movePlaylists.py", str(e))             
            message = ""
            if playlist_count == 0: message = message + "No playlists were restored up.\n"
            else: message = message + str(playlist_count) + " playlists were restored.\n"
            if data_count == 0: msesage = message + "No data was restored.\n"
            else: message = message + "Data was restored.\n"
            if cache_count == 0: message = message + "No cache was restored."
            else: message = message + "Cache was restored."
            xbmcgui.Dialog().ok(addon_name, message)
        else:
            xbmcgui.Dialog().ok(addon_name, "There are no playlists to copy (still using existing playlists)")
        
        
# Reopen the settings dialog
command = "Addon.OpenSettings(" + addon_id + ")"  
xbmc.executebuiltin(command)       

debugTrace("-- Exit movePlaylists.py --")
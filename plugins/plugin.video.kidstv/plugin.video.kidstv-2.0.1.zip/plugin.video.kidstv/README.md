Kids TV
=======

Present a bunch of playlists to the user that start with 'Kids '.  When a playlist is selected from the plugin it will either start to play or the contents will be displayed.  If it's a 'Kids Movies' playlist, the contents will always be displayed.
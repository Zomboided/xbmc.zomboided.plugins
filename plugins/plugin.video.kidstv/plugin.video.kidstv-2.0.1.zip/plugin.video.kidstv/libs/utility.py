#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2016 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Shared code fragments used by the add-on.

import xbmc
import xbmcaddon
import xbmcgui
import time

DEC_ERR = "*** DECODE ERROR *** : "


def ifDebug():
    if getID() == "": return False
    if xbmcaddon.Addon(getID()).getSetting("enable_debug") == "true":
        return True
    return False

    
def ifHTTPTrace():
    if getID() == "": return False
    if xbmcaddon.Addon(getID()).getSetting("enable_http") == "true":
        return True
    return False


def ifJSONTrace():
    if getID() == "": return False
    if xbmcaddon.Addon(getID()).getSetting("enable_json") == "true":
        return True
    return False
    
    
def debugTrace(data):
    try:
        if ifDebug():
            log = getVery() + " : " + data
            xbmc.log(msg=log, level=xbmc.LOGNONE)       
        else:
            log = getVery() + " : " + data
            xbmc.log(msg=log, level=xbmc.LOGDEBUG)
    except Exception as e:
        log = DEC_ERR + getVery() + data
        log = log.encode('ascii', 'ignore')
        xbmc.log(msg=log, level=xbmc.LOGDEBUG)

    
def errorTrace(module, data):
    log = getVery() + " : (" + module + ") " + data
    try:
        xbmc.log(msg=log, level=xbmc.LOGERROR)
    except Exception as e:
        log = DEC_ERR + log
        log = log.encode('ascii', 'ignore')
        xbmc.log(msg=log, level=xbmc.LOGNOTICE)

    
def infoTrace(module, data):
    log = getVery() + " : (" + module + ") " + data
    try:
        xbmc.log(msg=log, level=xbmc.LOGNOTICE)
    except Exception as e:
        log = DEC_ERR + log
        log = log.encode('ascii', 'ignore')
        xbmc.log(msg=log, level=xbmc.LOGNOTICE)

    
def infoPrint(data):
    try:
        xbmc.log(msg=data, level=xbmc.LOGNOTICE)
    except Exception as e:
        log = DEC_ERR + data
        log = log.encode('ascii', 'ignore')
        xbmc.log(msg=log, level=xbmc.LOGNOTICE)


def newPrint(data):
    xbmc.log(msg=data, level=xbmc.LOGERROR)

    
def now():
    return int(time.time())

    
def enum(**enums):
    return type('Enum', (), enums) 
    
    
def getID():
    return "plugin.video.kidstv"


def getVery():
    return "KidsTV"
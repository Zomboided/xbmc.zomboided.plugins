#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2016 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Define whether a playlist is play or display

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs
import os

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, newPrint, getID
from libs.common import getPlaylists, setHiddenPlaylists, getHiddenPlaylists, setAutoPlayPlaylists, getAutoPlayPlaylists, refreshJSONData, getPlaylistData
from libs.common import writeJSONData, getUserDataPath, LOCAL

THUMB = "Thumbnail"
POSTER = "Poster"
FANART = "Fan Art"
CLEAR = "[I]Clear all art[/I]"
OPTIONS = [THUMB, POSTER, FANART, CLEAR]


action = sys.argv[1]

debugTrace("-- Entered setPlaylists.py with parameter " + action + " --")

addon = xbmcaddon.Addon("plugin.video.kidstv")
addon_name = addon.getAddonInfo("name")
addon_id = addon.getAddonInfo('id')


if action == "hide":
    # Display the lists of playlists to hide
    playlists = getPlaylists(False, False)
    hidden = getHiddenPlaylists(playlists)
    selected = xbmcgui.Dialog().multiselect("Select Playlists To Hide", playlists, 0, hidden, False)
    if not selected == None:
        setHiddenPlaylists(playlists, selected)

    
elif action == "play":
    # Display the list of playlists to autoplay
    playlists = getPlaylists(False, False)
    autoplay = getAutoPlayPlaylists(playlists)
    selected = xbmcgui.Dialog().multiselect("Select Playlists To Auto Play", playlists, 0, autoplay, False) 
    if not selected == None:
        setAutoPlayPlaylists(playlists, selected)           
    
    
elif action == "art":
    playlists = getPlaylists(False, False)
    json_data = refreshJSONData(playlists)
    selected = xbmcgui.Dialog().select("Select playlist to change art", playlists)
    playlist = playlists[selected]
    found, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined = getPlaylistData(json_data, playlist, True)
    selected_art = xbmcgui.Dialog().select("Which art do you want to change?", OPTIONS,)
    if found:
        json_playlists = json_data.get("playlists")
        if OPTIONS[selected_art] == CLEAR:
            json_playlists = json_data.get("playlists")
            for p in json_playlists:
                if p.get("playlist") == playlist:
                    p["user defined"] = False
                    p["thumb"] = ""
                    p["poster"] = ""
                    p["fanart"] = ""                    
                    debugTrace("Cleared all artwork for " + playlist)
                    break
        else:
            file = xbmcgui.Dialog().browseSingle(2, "Select " + OPTIONS[selected_art], 'files', '.jpg|.png')
            if file == "":
                clear = False
                for p in json_playlists:
                    if p.get("playlist") == playlist:
                        if OPTIONS[selected_art] == THUMB and not thumb == "": clear = True
                        if OPTIONS[selected_art] == POSTER and not poster == "": clear = True
                        if OPTIONS[selected_art] == FANART and not fanart == "": clear = True                        
                        if clear:
                            if xbmcgui.Dialog().yesno(addon_name, "Do you want to delete existing " + OPTIONS[selected_art], "", "", "Cancel", "Delete"):
                                if OPTIONS[selected_art] == THUMB: p["thumb"] = ""
                                if OPTIONS[selected_art] == POSTER: p["poster"] = ""
                                if OPTIONS[selected_art] == FANART: p["fanart"] = ""
                                # FIXME Should clear user defined if everything is null
                                debugTrace("Cleared " + OPTIONS[selected_art] + " for " + playlist)
                        break
            else:
                # Just in case this is a windows file otherwise the JSON gets upset
                file = file.replace('\\', '/') 
                # Copy the selected file to the addon cache
                new_file = getUserDataPath("cache/" + playlist + "_" + OPTIONS[selected_art] + file[file.rindex("."):])
                cached_name = LOCAL + playlist + "_" + OPTIONS[selected_art] + file[file.rindex("."):]
                new_file = new_file.replace('\\', '/')
                file_copied = True
                try:
                    if xbmcvfs.exists(new_file): xbmcvfs.delete(new_file)
                except Exception as e:
                    errorTrace("setPlaylists.py", "Could not delete existing file " + new_file)
                    errorTrace("setPlaylists.py", str(e))
                    file_copied = False
                try:
                    xbmcvfs.copy(file, new_file)
                except Exception as e:
                    errorTrace("setPlaylists.py", "Could not copy " + file + " to " + new_file)
                    errorTrace("setPlaylists.py", str(e))
                    file_copied = False
                if file_copied :    
                    for p in json_playlists:
                        if p.get("playlist") == playlist:
                            p["user defined"] = True
                            if OPTIONS[selected_art] == THUMB: p["thumb"] = cached_name
                            if OPTIONS[selected_art] == POSTER: p["poster"] = cached_name
                            if OPTIONS[selected_art] == FANART: p["fanart"] = cached_name
                            debugTrace("Updated " + OPTIONS[selected_art] + " for " + playlist)
                            break
                else:
                    xbmcgui.Dialog().ok(addon_name, "Couldn't copy file to addon cache, error shown in log") 
        writeJSONData(json_data)
    else:
        errorTrace("setPlaylist.py", "Couldn't find playlist " + playlist + " to modify artwork")
    
# Reopen the settings dialog    
command = "Addon.OpenSettings(" + addon_id + ")"  
xbmc.executebuiltin(command)    

debugTrace("-- Exit setPlaylists.py --")

 
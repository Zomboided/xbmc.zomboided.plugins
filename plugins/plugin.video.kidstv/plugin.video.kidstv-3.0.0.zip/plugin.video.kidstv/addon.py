#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2015 Zomboided
#
#    Connection script called by the VPN Manager for OpenELEC settings screen
#    to validate a connection to a VPN provider.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Kids TV (makes a list of Kids smart playlists and displays them)

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import json

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, newPrint, getID
from libs.common import getPlaylists, setHiddenPlaylists, getHiddenPlaylists, setAutoPlayPlaylists, getAutoPlayPlaylists, LOCAL
from libs.common import refreshJSONData, getPlaylistData, getPlaylistsPath, readJSONData

# Set the addon name for use in the dialogs
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo("name")

# Get the arguments passed in
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = sys.argv[2].split("?", )
action = ""
params = ""
# If an argument has been passed in, the first character will be a ?, so the first list element is empty
inc = 0
for token in args:
    if inc == 1 : action = token
    if inc > 1 : params = params + token
    inc = inc + 1


def listShows():
    # Get the list of shows (based on smart playlist names)  
    playlists = getPlaylists(False, False)
    # Make sure we're displaying the latest data
    json_data = refreshJSONData(playlists)
    # Build the list of playlists
    if len(playlists) > 0:
        for playlist in playlists:
            found, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined = getPlaylistData(json_data, playlist, False)  
            if found and not hidden:
                url = base_url + "?play?" + getPlaylistsPath(playlist + ".xsp")
                if not title == "" : li = xbmcgui.ListItem(title)
                else: li = xbmcgui.ListItem(playlist)
                if not plot == "" : li.setInfo("video", {"plot" : plot})
                # Use poster as thumb if no thumb
                if not thumb == "" : li.setArt({"thumb" : thumb})
                elif not poster == "" : li.setArt({"thumb" : poster})
                if not fanart == "" : li.setArt({"fanart" : fanart})
                if not poster == "" : li.setArt({"poster" : poster})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.setContent(addon_handle, "tvshows")
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().ok(addon_name, "Create some Kids TV smart playlists to show a list of channels to choose from.")
    return

    
def playPlaylist():
    playlist = params[params.rfind("/")+1:params.rfind(".")]
    debugTrace("Playing playlist " + playlist)
    json_data = readJSONData()
    found = False
    autoplay = False
    if not json_data == None:
        found, title, plot, thumb, fanart, poster, hidden, autoplay, user_defined = getPlaylistData(json_data, playlist, False)
    if found and autoplay:
        command = "PlayMedia(" + params + ")"
    else:
        command = "ActivateWindow(Videos," + params + ",return)"
    xbmc.executebuiltin(command)
    
    
# Process the incoming request
if action == "play" : playPlaylist()
else: listShows()
    
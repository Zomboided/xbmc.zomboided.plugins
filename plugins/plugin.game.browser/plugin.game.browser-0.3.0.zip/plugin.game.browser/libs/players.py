#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    This module will display a player selection screen

import xbmcaddon
import xbmcgui
from libs.utility import debugTrace, errorTrace, infoTrace, getID, newPrint
from libs.playerdb import player_db

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

# Class to display up to 4 players
class PlayerBox(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.caption = kwargs.get("caption", "")
        self.players = kwargs.get("players", "")
        xbmcgui.WindowXMLDialog.__init__(self)

    def onInit(self):
        # Display the caption
        self.getControl(100).setLabel(self.caption)
        # Update each of the 5 player objects either with data or to remove visibility
        i = 1
        self.players.startBrowse()
        # Get the player count so the x pos can be modified if it's an even number
        player_count = self.players.getCount()
        while self.players.morePlayers():
            player = self.players.nextPlayer()
            self.getControl(2000+i).setLabel(player.getName())
            if player_count == 2 or player_count == 4:
                x = self.getControl(2000+i).getX()
                x = x - 160
                y = self.getControl(2000+i).getY()
                self.getControl(2000+i).setPosition(x,y)
            self.getControl(2000+i).setVisible(True)
            self.getControl(2010+i).setImage(player.getIcon())
            self.getControl(2010+i).setVisible(True)
            if player_count == 2 or player_count == 4:
                x = self.getControl(2010+i).getX()
                x = x - 160
                y = self.getControl(2010+i).getY()
                self.getControl(2010+i).setPosition(x,y)
            i += 1
        while i<=5:
            self.getControl(2000+i).setVisible(False)
            self.getControl(2010+i).setVisible(False)
            i+= 1
        # Finally set the default focus to Player 1, in the middle of the screen
        self.setFocusId(2001)

    def onAction(self, action):
        actionId = action.getId()
        if actionId in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            return self.close()
        

def showPlayerBox(caption, players):
    path = xbmcaddon.Addon(getID()).getAddonInfo("path")
    win = PlayerBox("playerbox.xml", path, caption=caption, players=players)
    win.doModal()
    del win
    

def playerSelection():
    addon = xbmcaddon.Addon(getID())
    players = player_db()
    count = players.getCount()
    if count == 0 or count == 1:
        return count
    else:
        showPlayerBox("Select Player", players)
        win = xbmcgui.Window(10000)
        try:
            selected = int(win.getProperty('game.browser_playerbox'))
        except:
            selected = -1
        return selected
        
        

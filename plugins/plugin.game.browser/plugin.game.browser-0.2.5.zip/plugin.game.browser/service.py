#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Service module for Game Browser add-on

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import time
import datetime
import calendar
from libs.utility import ifDebug, debugTrace, errorTrace, infoTrace, newPrint, getID
from libs.gamedb import getGame, setGame, deleteSave, backupSave


# Player class which will be called when the playback state changes           
class KodiPlayer(xbmc.Player):
    
    def __init__ (self):
        xbmc.Player.__init__(self)
        self.logger = None

    def onPlayBackStarted(self, *arg):
        rom, player = getGame()
        debugTrace("Game " + rom + " started for player " + str(player))
    
    def onPlayBackError(self, *arg):
        debugTrace("Game " + rom + " errored out for player " + str(player) + ", state not preserved")
    
    def onPlayBackStopped(self, *arg):
        gameOver("stopped")
        
    def onPlayBackEnded(self, *arg):
        gameOver("ended")


def gameOver(call):
    # Store the .sav for the player for subsequent games
    rom, player = getGame()
    # Clear the game so we don't do this twice
    setGame("", 0)
    if not rom == "": debugTrace("Game " + rom + " " + call + " for player " + str(player))
    if player > 0 and not rom == "":
        deleteSave(rom, player)
        backupSave(rom, player)

        
if __name__ == '__main__':   

    addon = xbmcaddon.Addon(getID())
    infoTrace("service.py", "Starting Game Browser service, version is " + addon.getAddonInfo("version"))
    infoTrace("service.py", "Kodi build is " + xbmc.getInfoLabel('System.BuildVersion'))

    # This whole module is just to instantiate a player to detect when games start/stop
    player = KodiPlayer()
    
    # Nothing to do in the loop other than wait for the abort
    monitor = xbmc.Monitor()    
    while not monitor.abortRequested():
        if monitor.waitForAbort(60):
            # Abort was requested while waiting. We should exit
            break

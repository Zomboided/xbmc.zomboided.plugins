#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Display all of the installed retrolib cores for the user to select

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from libs.utility import debugTrace, errorTrace, infoTrace, getID, getName, newPrint
from libs.gamedb import parseTitle, getCore, setCore, getSystem

debugTrace("-- Entered selectcore.py")

system = sys.argv[1]


def getCores(current_core):
    # Return the list of retrolib cores
    cores = []
    current_core_index = -1
    addon_path = xbmc.translatePath("special://home/addons/")
    try:
        dirs, files = xbmcvfs.listdir(addon_path)
        if len(dirs) > 0:
            i = 0
            for dir in dirs:
                if dir.startswith("game.libretro."):
                    if dir == current_core: 
                        current_core_index = i
                    cores.append(dir)
                    i += 1
    except Exception as e:  
        errorTrace("common.py", "Couldn't get a list of game.libretro cores from " + addon_path)
        errorTrace("common.py", str(e))
        cores = []
    return cores, current_core_index


if not getID() == "":
    addon = xbmcaddon.Addon(getID())
    addon_name = getName()
    cores, current_core_index = getCores(getCore(system))
    if len(cores) > 0:
        i = xbmcgui.Dialog().select("Select " + getSystem(system) + " emulation core" , cores, False, current_core_index, True)
        if i >= 0:
            setCore(system, cores[i])
    else:
        xbmcgui.Dialog().ok(addon_name, "No libretro cores were found, install some and try again")   
    command = "Addon.OpenSettings(" + getID() + ")"
    xbmc.executebuiltin(command)
else:
    errorTrace("passwordpopup.py", "Game browser is not ready")
    
debugTrace("-- Exit selectcore.py --")





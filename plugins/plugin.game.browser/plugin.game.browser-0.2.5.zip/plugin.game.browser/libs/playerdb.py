#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Player Database class.
  
import xbmcvfs
import os.path
import xbmcaddon

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, ifJSONTrace, newPrint, getID

class player_db:
    # This class represents a database of players
    def __init__(self):
        self.players = []
        # This should be built from a database
        self.players.append(player_item("Orson", "sonic.png"))
        self.players.append(player_item("Daddy", "donkey.png"))
        self.players.append(player_item("Neiva", "peach.png"))
        self.player_count = len(self.players)

    def startBrowse(self):
        restartBrowse(self)
        return self.player_count
    
    def nextGame(self):
        self.curr_index += 1;
        return self.players[self.curr_index]
        
    def moreGames(self):
        # True if there are more games to browse
        if self.curr_index < (self.player_count-1):
            return True
        else:
            return False
            
    def addPlayer(self, player):
        self.players.append(player)
        
    def deletePlayer(self, i):
        newPrint("Delete")
        # Save states need to be deleted/renamed
    
    def getCount(self):
        return self.player_count
    

class player_item:
    # This class represents a single player

    def __init__(self, name, icon):
        self.name = name
        self.icon = icon
        
    def getName(self):
        return self.name
        
    def getIcon(self):
        return self.icon    
  
    
    
#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2018 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    This module will display a player selection screen

import xbmcaddon
import xbmcgui
from libs.utility import debugTrace, errorTrace, infoTrace, getID
from libs.playerdb import player_db

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92


# Class to display up to 4 players
class PlayerBox(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.caption = kwargs.get("caption", "")
        xbmcgui.WindowXMLDialog.__init__(self)

    def onInit(self):
    
        # This should all be read from a player database
        self.getControl(100).setLabel(self.caption)
        self.getControl(2001).setLabel("Orson")
        self.getControl(2001).setVisible(True)
        self.getControl(2011).setImage("sonic small.png")
        self.getControl(2011).setVisible(True)
        self.getControl(2002).setLabel("Daddy")
        self.getControl(2002).setVisible(True)
        self.getControl(2012).setImage("donkey small.png")
        self.getControl(2012).setVisible(True)
        self.getControl(2003).setLabel("Neiva Diva")
        self.getControl(2003).setVisible(True)
        self.getControl(2013).setImage("peach small.png")
        self.getControl(2013).setVisible(True)
        self.getControl(2004).setVisible(False)
        self.getControl(2014).setVisible(False)
        self.getControl(2005).setVisible(False)
        self.getControl(2015).setVisible(False)
        
        # Set the default focus to Player 1, in the middle of the screen
        self.setFocusId(2001)

    def onAction(self, action):
        actionId = action.getId()
        if actionId in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            return self.close()
        

def showPlayerBox(caption):
    path = xbmcaddon.Addon(getID()).getAddonInfo("path")
    #win = InfoBox("playerbox.xml", path, caption=caption, text_left=text_l, text_right=text_r)
    win = PlayerBox("playerbox.xml", path, caption=caption)
    win.doModal()
    del win
    

def playerSelection():
    addon = xbmcaddon.Addon(getID())
    players = player_db()
    count = players.getCount()
    if count == 0 or count == 1:
        return count
    else:
        showPlayerBox("Select Player")
        win = xbmcgui.Window(10000)
        return int(win.getProperty('game.browser_playerbox'))
    
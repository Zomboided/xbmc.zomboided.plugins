#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Game Database class.
  
import xbmcvfs
import os.path
import xbmcaddon

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, ifJSONTrace, newPrint, getID

POSTER_EXT = ".box"
FANART_EXT = ".fanart"
THUMB_EXT = ".thumb"
SYSTEMS = ["genesis", "snes", "playstation"]

class game_db:
    # This class represents a database of all of the games.  It gathers data using lists of files
    # rather than any pre-formed DB files.  In the future it could be read from Kodi data repositories

    def __init__(self):
        self.settings = []
        self.game_paths = []
        self.art_paths = []
        self.extensions = []
        addon = xbmcaddon.Addon()
        for system in SYSTEMS:
            roms = addon.getSetting(system + "_roms")
            if not roms == "":
                self.settings.append(system)
                self.game_paths.append(roms)
                self.art_paths.append(addon.getSetting(system + "_art"))
                self.extensions.append(addon.getSetting(system + "_ext"))
        
    def startBrowse(self):
        self.gamedb = []
        self.gamecount = 0
        self.restartBrowse()
        i = 0
        for path in self.game_paths:
            path = os.path.normpath(path) + os.sep
            roms = listDirectoryContents(path, self.extensions[i])
            if not roms == None:
                for rom in roms:
                    artpath = os.path.normpath(self.art_paths[i]) + os.sep
                    poster, fanart, thumb = parseArt(artpath, rom)
                    self.gamedb.append(game_item(parseTitle(rom), self.settings[i], parseRom(self.game_paths[i], rom), poster, fanart, thumb, ""))
                    self.gamecount += 1
            i += 1
        return self.gamecount
    
    def restartBrowse(self):
        self.curr_index = -1
    
    def nextGame(self):
        # Title, System, ROM, Poster, FanArt, plot
        self.curr_index += 1;
        return self.gamedb[self.curr_index]
        
    def moreGames(self):
        # True if there are more games to browse
        if self.curr_index < (self.gamecount-1):
            return True
        else:
            return False


class game_item:
    # This class represents a single game with all of the data associated with it

    def __init__(self, title, setting, rom, poster, fanart, thumb, plot):
        self.title = title
        self.setting = setting
        self.rom = rom
        self.poster = poster
        self.fanart = fanart
        self.thumb = thumb
        self.plot = plot
        
    def getTitle(self):
        return self.title
        
    def getSetting(self):
        return self.setting
        
    def getROM(self):
        return self.rom
        
    def getPoster(self):
        return self.poster
        
    def getFanArt(self):
        return self.fanart
    
    def getThumb(self):
        return self.thumb
    
    def getPlot(self):
        return self.plot
    


def getSystem(setting):
    # For a given system, return the system Title
    addon = xbmcaddon.Addon(getID())
    return addon.getSetting(setting + "_name")


def getCore(setting):
    # For a given system, return the system core
    addon = xbmcaddon.Addon(getID())
    return addon.getSetting(setting + "_core")    


def setCore(setting, core):
    # Update the default core
    addon = xbmcaddon.Addon(getID())
    addon.setSetting(setting + "_core", core)
    return 

    
def parseTitle(rom):
    # Extract the title to use from the ROM filename
    return rom[:rom.rfind(".")]


def parseRom(path, rom):
    # Append the rom to the path for a fully qualified filename
    return os.path.join(path, rom)
    

def parseArt(path, rom):
    # Return the fully qualified filename for the poster and fanart if they exist
    title = parseTitle(rom)
    poster = os.path.join(path, (title + POSTER_EXT))
    fanart = os.path.join(path, (title + FANART_EXT))
    thumb = os.path.join(path, (title + THUMB_EXT))
    if xbmcvfs.exists(poster + ".jpg"):
        poster = poster + ".jpg"
    elif xbmcvfs.exists(poster + ".png"):
        poster = poster + ".png"
    else:
        poster = ""
    if xbmcvfs.exists(fanart + ".jpg"):
        fanart = fanart + ".jpg"
    elif xbmcvfs.exists(fanart + ".png"):
        fanart = fanart + ".png"
    else:
        fanart = ""
    if xbmcvfs.exists(thumb + ".jpg"):
        thumb = thumb + ".jpg"
    elif xbmcvfs.exists(thumb + ".png"):
        thumb = thumb + ".png"
    else:
        thumb = ""
    return poster, fanart, thumb


# Return a list of all files in a directory with the given extension
def listDirectoryContents(path, extensions):
    contents = []
    try:
        debugTrace("Getting the " + extensions + " files in " + path)
        if xbmcvfs.exists(path):
            dirs, files = xbmcvfs.listdir(path)
            if len(files) > 0:
                for file in files:
                    # FIXME allow for multiple extensions
                    if file.endswith(extensions):
                        contents.append(file)
        if len(contents) > 0:
            return contents
        else:
            debugTrace("None found!")
            return None
    except Exception as e:  
        errorTrace("gamedb.py", "Couldn't list " + games_path)
        errorTrace("gamedb.py", str(e)) 



  
    
    
#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2019 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Shared code fragments used by the add-on.

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
import urllib

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, ifJSONTrace, newPrint, getID


def getGames():
    # Get the current set of games
    addon = xbmcaddon.Addon(getID())
    game_paths = getGamePaths()
    games = []
    try:
        for path in game_paths:
            if xbmcvfs.exists(path + "games\\"): newPrint("Exists")
            else: newPrint(path + "No exist")
            debugTrace("Listing games from " + path)
            dirs, files = xbmcvfs.listdir(path + "games\\")
            if len(files) > 0:
                for file in files:          
                    newPrint(file)
                    if file.endswith(".gen"):
                        games.append(file[:-4])
    except Exception as e:  
        errorTrace("common.py", "Couldn't list " + games_path)
        errorTrace("common.py", str(e))    
    return games


def getGamePaths():
    return ["X:\\Emulation\\roms\\Genesis\\"]
    #return [] 


def getUserDataPath(file):
    path = "special://userdata/addon_data/" + getID() + "/"
    if not file == "": path = path + file
    return xbmc.translatePath(path)    
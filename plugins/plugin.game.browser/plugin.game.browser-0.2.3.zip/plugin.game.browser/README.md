Game Browser
============

Really simple game browser that puts everything in one big list and uses video views to display the options.
#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2015 Zomboided
#
#    Connection script called by the VPN Manager for OpenELEC settings screen
#    to validate a connection to a VPN provider.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Game Browser main listing module

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import json

from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, newPrint, getID
#from libs.common import getGames, getGamePaths
from libs.gamedb import game_db, game_item, getSystem, getCore


# Set the addon name for use in the dialogs
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo("name")

# Get the arguments passed in
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = sys.argv[2].split("?", )
action = ""
system = ""
game = ""
# If an argument has been passed in, the first character will be a ?, so the first list element is empty
inc = 0
for token in args:
    if inc == 1 : action = token
    if inc == 2 : system = token
    if inc > 2 : game = game + token
    inc += 1


def listGames():
    # Retrieve the games DB and start browsing it to create the page
    games = game_db()
    if games.startBrowse() > 0:
        while(games.moreGames()):
            game = games.nextGame()
            li = xbmcgui.ListItem(game.getTitle(), iconImage = "")
            command = []
            script = "special://home/addons/plugin.game.browser/deletesave.py"
            command.append(("Delete save state", "XBMC.RunScript(" + script + ", " + game.getROM() + ")", ))
            # Add other context items here
            li.addContextMenuItems(command)
            plot = game.getPlot()
            if not plot == "" : li.setInfo("video", {"plot" : plot})
            fanart = game.getFanArt()
            if not fanart == "" : li.setArt({"fanart" : fanart})
            poster = game.getPoster()
            if not poster == "" : li.setArt({"poster" : poster})
            thumb = game.getThumb()
            if not thumb == "": li.setArt({"thumb" : thumb})
            url = base_url + "?play?" + game.getSetting() + "?" + game.getROM()
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.setContent(addon_handle, "games")
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().ok(addon_name, "No games were found")
    return

    
def playGame():
    title = game[game.rfind("/")+1:game.rfind(".")]
    debugTrace("Playing game " + title + " on system " + system)
    game_item = xbmcgui.ListItem()
    game_parameters = {'title' : title, 'platform' : getSystem(system), 'gameclient' : getCore(system)}
    game_item.setInfo(type = 'game', infoLabels = game_parameters)
    xbmc.Player().play(game, game_item)


def AddContextItem(name,script,arg):
    commands = []
    runner = "XBMC.RunScript(" + str(script)+ ", " + str(arg) + ")"
    commands.append(( "Stay Safe", runner, ))
    commands.append(( "Happy Holidays", runner, ))
    commands.append(( "You cunt", runner, ))
    return commands
      
    
# Process the incoming request
if action == "play" : playGame()
else: listGames()
    
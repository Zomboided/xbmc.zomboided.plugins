#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Delete a save state associated with a ROM

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os.path
from libs.utility import debugTrace, errorTrace, infoTrace, getID, getName, newPrint
from libs.gamedb import parseTitle

rom = sys.argv[1]

debugTrace("-- Entered deletesave.py with " + str(rom))

save = rom[:rom.rfind(".")] + ".sav"

path, rom = os.path.split(save)
rom = parseTitle(rom)

try:
    if xbmcvfs.exists(save):
        debugTrace("Deleting save file " + save)
        xbmcvfs.delete(save)
        xbmcgui.Dialog().ok(getName(), "Deleted " + rom + " save state")
    else:
        xbmcgui.Dialog().ok(getName(), "No save state exists for " + rom)
        debugTrace("No save file")
except Exception as e:  
    errorTrace("deletesave.py", "Couldn't delete save state " + save)
    errorTrace("deletesave.py", str(e))
    xbmcgui.Dialog().ok(getName(), "An error occurred, check the log")
    
debugTrace("-- Exit deletesave.py --")





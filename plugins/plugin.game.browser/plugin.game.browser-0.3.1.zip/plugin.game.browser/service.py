#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Service module for Game Browser add-on

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import time
import datetime
import calendar
from libs.utility import ifDebug, debugTrace, errorTrace, infoTrace, newPrint, getID, now
from libs.gamedb import getGame, setGame, deleteSave, backupSave


# Monitor class which will get called when the settings change    
class KodiMonitor(xbmc.Monitor):

    # This gets called every time a setting is changed either programmatically or via the settings dialog.
    def onSettingsChanged( self ):
        updateSettings()


def updateSettings():
    global parental
    global parental_override
    global parental_max
    global parental_stop
    global parental_delay
    debugTrace("Updating settings")
    addon = xbmcaddon.Addon(getID())
    if addon.getSetting("parental_enabled") == "true": parental = True
    else: parental = False
    if addon.getSetting("parental_override") == "true": parental_override = True
    else: parental_override = False
    if isWeekend():
        parental_max = int(addon.getSetting("weekend_timer"))
    else:
        parental_max = int(addon.getSetting("week_timer"))
    # Convert max timer to seconds
    parental_max = parental_max * 60        
    if addon.getSetting("prevent_gaming") == "Yes": 
        parental_stop = True
        # Stop the game a minute after warning
        parental_delay = -1
    elif addon.getSetting("prevent_gaming") == "Delayed":
        parental_stop = True
        parental_delay = 0-(int(addon.getSetting("delay_duration")))
    else:
        parental_stop = 0
        parental_delay = 0
    
    
# Player class which will be called when the playback state changes           
class KodiPlayer(xbmc.Player):
    
    def __init__ (self):
        xbmc.Player.__init__(self)
        self.logger = None
        self.play_start = 0 
        self.play_end = 0
        self.game_on = False

    def onPlayBackStarted(self, *arg):
        updateSettings()
        rom, player = getGame()
        if not rom == "": 
            self.play_start = now()
            self.play_end = self.play_start + getParentalRemainingToday()
            self.game_on = True
            if isParentalOn(): 
                debugTrace("Game " + rom + " started for player " + str(player) + " at " + str(self.play_start) + " until " + str(self.play_end))
                remain = getParentalMinutesLeft(0)
                if remain == 1:
                    xbmcgui.Dialog().notification("Parental controls on", "Less than " + str(remain) + " minute play time remaining", "special://skin/extras/icons/clock.png", 3000, True)
                else:
                    if (remain * 60) >= getParentalMax():
                        remain = (getParentalMax() / 60)
                        xbmcgui.Dialog().notification("Parental controls on", str(remain) + " minutes play time today", "special://skin/extras/icons/clock.png", 3000, True)
                    else:
                        xbmcgui.Dialog().notification("Parental controls on", "Less than " + str(remain) + " minutes play time remaining", "special://skin/extras/icons/clock.png", 3000, True)
            else: 
                debugTrace("Game " + rom + " started for player " + str(player))
            

    def onPlayBackError(self, *arg):
        if self.game_on:
            self.game_on = False
            debugTrace("Game " + rom + " errored out for player " + str(player) + ", state not preserved")
    
    def onPlayBackStopped(self, *arg):
        if self.game_on:
            self.gameOver("stopped")
        
    def onPlayBackEnded(self, *arg):
        if self.game_on:
            self.gameOver("ended")

    def gameOver(self, call):        
        # Register the game has finished and total up any playtime
        # Store the .sav for the player for subsequent games
        self.game_on = False
        rom, player = getGame()
        # Clear the game so we don't do this twice
        setGame("", 0)    
        if not rom == "": debugTrace("Game " + rom + " " + call + " for player " + str(player))
        if player > 0 and not rom == "":
            deleteSave(rom, player)
            backupSave(rom, player)
            # Record the play time
            game_time = now() - self.play_start
            if isParentalOn(): 
                addParentalToday(game_time)
                debugTrace("Game was played for " + str(game_time) + " seconds, with " + str(getParentalToday()) + " seconds total play today, and " + str(getParentalRemainingToday()) + " seconds remaining")
            self.play_start = 0
            self.play_end = 0
                
    def getPlayTime(self):
        return now() - self.play_start
        
    def isGame(self):
        return self.game_on


def isParentalOn():
    # Are parental controls on or not
    global parental
    global parental_override
    if parental and not parental_override: return True
    else: return False
    
def getParentalMax():
    # Return the active timer maximum
    global parental_max
    return parental_max

def getParentalToday():
    # Time played today in seconds
    global today_time
    return today_time
    
def setParentalToday(secs):
    # Set time played today to seconds value passed in
    global today_time
    today_time = secs
    storeParentalRemainingToday()
    
def addParentalToday(secs):
    # Add seconds value to time played today
    global today_time
    today_time = today_time + secs
    storeParentalRemainingToday()

def storeParentalRemainingToday():
    # Store the remaining time on a window for the launcher to view it
    win = xbmcgui.Window(10000)
    win.setProperty('game.browser_parental_timer', str(getParentalRemainingToday()))

def getParentalRemainingToday():
    # Return amount of seconds remaining to play today/
    remaining = getParentalMax() - getParentalToday()
    if remaining < 0: remaining = 0
    return remaining

def getParentalMinutesLeft(current_playtime):
    # How many minutes left to play, including current playtime.  Negative mins is time past time out
    total_to_now = getParentalToday() + current_playtime
    total_remaining = getParentalMax() - total_to_now
    return (total_remaining / 60) + 1

def resetParentalTimer():
    # Turn off override, reset timer, get fresh daily timer settings
    addon = xbmcaddon.Addon(getID())
    addon.setSetting("parental_override", "false")
    setParentalToday(0)
    updateSettings()

def isWeekend():
    # Is the weekend here
    if getDay() < 5: return False
    return True

def getDay():
    # Return day of the week (0 is Monday, 6 is Sunday)
    return datetime.datetime.today().weekday()

def checkDay():
    # Reset the timer when the day changes
    global timer_day
    d = getDay()
    if not timer_day == d:
        resetParentalTimer()
        timer_day = d

if __name__ == '__main__':   

    addon = xbmcaddon.Addon(getID())
    infoTrace("service.py", "Starting Game Browser service, version is " + addon.getAddonInfo("version"))
    infoTrace("service.py", "Kodi build is " + xbmc.getInfoLabel('System.BuildVersion'))

    today_time = 0
    parental = False
    parental_override = False
    parental_max = 0
    parental_stop = 0
    parental_delay = 0
    warn_timer = 0
    timer_day = getDay()
    
    # Load all the settings
    updateSettings()
    
    # Reset the parental timer
    resetParentalTimer()
    
    # This whole module is just to instantiate a player to detect when games start/stop
    player = KodiPlayer()
    monitor = xbmc.Monitor()    
    while not monitor.abortRequested():
        # Check if games can still be played.  Times are generally rounded to a minute and not mega accurate
        if player.isPlaying()  and player.isGame() and isParentalOn():        
            mins_left = getParentalMinutesLeft(player.getPlayTime())
            if mins_left == 0:
                xbmcgui.Dialog().notification("Time to stop playing!", "0 minutes left", "special://skin/extras/icons/clock.png", 10000, True)
                warn_timer = 0
            if mins_left ==1:
                xbmcgui.Dialog().notification("Nearly time to stop playing!", str(mins_left) + " minute left", "special://skin/extras/icons/clock.png", 3000, True)
            if mins_left == 2 or mins_left == 5: 
                xbmcgui.Dialog().notification("Nearly time to stop playing!", str(mins_left) + " minutes left", "special://skin/extras/icons/clock.png", 3000, True)
            if mins_left < 0:
                warn_timer += 1
                if parental_stop and (parental_delay == mins_left):
                    player.stop()
                    xbmcgui.Dialog().notification("No play time left today", "Parental controls on", "special://skin/extras/icons/clock.png", 5000, True)
                else:
                    if warn_timer == 5:
                        xbmcgui.Dialog().notification("Time to stop playing now!", "0 minutes left", "special://skin/extras/icons/clock.png", 20000, True)
                        warn_timer == 0
        
        # Reset the timer each day.  If you were playing a game over midnight and then stopped, you'd get a new load of time
        # for the next day.  Could lock games out by an hour or similar, but are kids gonna be playing at midnight to exploit?....
        if not player.isPlaying():
            checkDay()
        
        if monitor.waitForAbort(60):
            # Abort was requested while waiting. We should exit
            infoTrace("service.py", "Abort received, shutting down service")
            break

#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2020 Zomboided
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    Player Database class.
  
import xbmcvfs
import os.path
import xbmcaddon
import json
import os
from libs.utility import debugTrace, infoTrace, errorTrace, ifDebug, ifJSONTrace, newPrint, getID

PLAYERDB = "playerdb.json"

class player_db:
    # This class represents a database of players
    def __init__(self):
        self.players = []
        playerdb_json = loadPlayerDB()
        if not playerdb_json == None:
            for player in playerdb_json["players"]:
                self.players.append(player_item(player["name"], player["icon"]))
        self.player_count = len(self.players)

    def startBrowse(self):
        self.curr_index = -1
        return self.player_count
    
    def nextPlayer(self):
        self.curr_index += 1;
        return self.players[self.curr_index]
        
    def morePlayers(self):
        # True if there are more games to browse
        if self.curr_index < (self.player_count-1):
            return True
        else:
            return False
            
    def addPlayer(self, player):
        self.players.append(player)
        
    def deletePlayer(self, i):
        newPrint("Delete")
        # Save states need to be deleted/renamed
    
    def getCount(self):
        return self.player_count
    

def loadPlayerDB():
    addon = xbmcaddon.Addon(getID())
    playerdb_file = addon.getSetting("playerdb")
    if playerdb_file == "":
        # Don't know where the playerdb file will be found
        return None
    playerdb_file = os.path.join(playerdb_file, PLAYERDB)
    if xbmcvfs.exists(playerdb_file):
        # File exists so open it and load it as JSON
        try:
            json_file = open(playerdb_file, "r")
            playerdb_json = json.load(json_file)
            json_file.close()
            debugTrace("Loaded player database from " + playerdb_file)
            return playerdb_json
        except Exception as e:  
            errorTrace("players.py", "Couldn't load player database JSON file " + addon_path)
            errorTrace("players.py", str(e))
            return None
    else:
        # No file exists / players have not been created
        return None
    
    
    
def getUserDataPath(path):
    return xbmc.translatePath("special://userdata/addon_data/" + getID() + "/" + path)




class player_item:
    # This class represents a single player

    def __init__(self, name, icon):
        self.name = name
        self.icon = icon
        
    def getName(self):
        return self.name
        
    def getIcon(self):
        return self.icon    
  
    
    
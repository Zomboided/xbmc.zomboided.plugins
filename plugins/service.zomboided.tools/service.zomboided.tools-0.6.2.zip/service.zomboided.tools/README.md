Zomboided Tools
===============

This add-on is a service for Kodi provides a seemingly random selection of tools for Kodi.

It allows the user to limit the playback of playlists

Full instructions can be found on the GitHub wiki for this project at https://github.com/Zomboided/service.zomboided.tools